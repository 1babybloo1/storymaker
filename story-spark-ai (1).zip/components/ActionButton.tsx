import React from 'react';
import { LoadingSpinner } from './LoadingSpinner';

interface ActionButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children: React.ReactNode;
  variant?: 'primary' | 'secondary';
  isLoading?: boolean;
}

export const ActionButton: React.FC<ActionButtonProps> = ({ 
  children, 
  variant = 'primary', 
  isLoading = false, 
  className = '', 
  ...props 
}) => {
  const baseStyles = "px-5 py-2.5 rounded-lg font-semibold transition-all duration-150 ease-in-out focus:outline-none focus:ring-4 shadow-md hover:shadow-lg transform active:scale-95";
  
  // Updated gradient styles
  const primaryStyles = "bg-gradient-to-r from-sky-500 to-cyan-400 hover:from-sky-600 hover:to-cyan-500 text-white focus:ring-sky-300/70";
  const secondaryStyles = "bg-gradient-to-r from-purple-500 to-fuchsia-500 hover:from-purple-600 hover:to-fuchsia-600 text-white focus:ring-purple-400/70";
  
  const disabledStyles = "opacity-60 cursor-not-allowed shadow-none hover:shadow-none";

  const variantStyles = variant === 'primary' ? primaryStyles : secondaryStyles;

  return (
    <button
      className={`${baseStyles} ${variantStyles} ${props.disabled || isLoading ? disabledStyles : ''} ${className}`}
      disabled={props.disabled || isLoading}
      {...props}
      aria-live="polite" // Indicates loading state changes
      aria-busy={isLoading}
    >
      {isLoading ? (
        <span className="flex items-center justify-center">
          <LoadingSpinner size="sm" />
          <span className="ml-2">{typeof children === 'string' && children.includes('...') ? children.replace('...', '') : 'Loading'}...</span>
        </span>
      ) : (
        children
      )}
    </button>
  );
};