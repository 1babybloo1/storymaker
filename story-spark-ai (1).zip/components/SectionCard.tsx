import React from 'react';

interface SectionCardProps {
  title: string;
  children: React.ReactNode;
  actions?: React.ReactNode;
  className?: string;
}

export const SectionCard: React.FC<SectionCardProps> = ({ title, children, actions, className = '' }) => {
  return (
    <section 
      className={`bg-slate-800/60 backdrop-blur-lg p-5 md:p-6 rounded-xl shadow-2xl ring-1 ring-slate-700/50 ${className}`}
      aria-labelledby={`section-title-${title.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-4 pb-4 border-b border-slate-700/60">
        <h2 
          id={`section-title-${title.toLowerCase().replace(/\s+/g, '-')}`} 
          className="text-2xl font-semibold text-sky-400 mb-2 sm:mb-0"
        >
          {title}
        </h2>
        {actions && <div className="flex space-x-3 flex-shrink-0 mt-2 sm:mt-0">{actions}</div>}
      </div>
      <div>{children}</div>
    </section>
  );
};