import React from 'react';

export const Header: React.FC = () => {
  return (
    <header className="bg-slate-900/80 backdrop-blur-md shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4 py-5 md:px-8">
        <h1 className="text-4xl font-bold">
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-sky-400 to-fuchsia-500">
            Story Spark AI ✨
          </span>
        </h1>
        <p className="text-slate-400 mt-1">Your AI co-writer for brilliant stories.</p>
      </div>
    </header>
  );
};