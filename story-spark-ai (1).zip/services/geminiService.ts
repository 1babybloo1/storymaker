import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { 
  GEMINI_MODEL_TEXT, 
  IDEAS_PROMPT_PREFIX, 
  PARAGRAPH_SYSTEM_INSTRUCTION,
  PARAGRAPH_CONTEXT_INSTRUCTION_SUFFIX,
  EDIT_SUGGESTION_SYSTEM_INSTRUCTION
} from '../constants';

const apiKey = process.env.API_KEY;

if (!apiKey) {
  console.error("API_KEY environment variable is not set. Gemini API calls will fail.");
}

const ai = new GoogleGenAI({ apiKey: apiKey || "MISSING_API_KEY_FALLBACK" }); 

export const fetchStoryIdeas = async (count: number = 3): Promise<string[]> => {
  if (!apiKey) throw new Error("API Key is not configured.");
  try {
    const specificIdeasPrompt = `${IDEAS_PROMPT_PREFIX} Generate ${count} diverse ideas.`;
    
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_TEXT,
      contents: specificIdeasPrompt,
    });

    const text = response.text;
    if (!text) return [];

    return text
      .split(/IDEA:/g)
      .map(idea => idea.trim().replace(/^\d+\.\s*/, '')) // Remove "IDEA:" and leading numbers
      .filter(idea => idea.length > 5); // Filter out very short or empty lines

  } catch (error) {
    console.error('Error fetching story ideas:', error);
    if (error instanceof Error) {
        throw new Error(`Failed to fetch story ideas from Gemini API: ${error.message}`);
    }
    throw new Error('An unknown error occurred while fetching story ideas.');
  }
};

export const generateStoryParagraph = async (prompt: string, currentStory?: string): Promise<string> => {
  if (!apiKey) throw new Error("API Key is not configured.");
  if (!prompt || prompt.trim() === '') {
    throw new Error('Prompt cannot be empty.');
  }
  try {
    let fullPrompt = prompt;
    if (currentStory && currentStory.trim() !== '') {
      fullPrompt = `Given the story so far:\n"${currentStory}"\n\nContinue the story based on this prompt: "${prompt}"`;
    }

    const systemInstruction = PARAGRAPH_SYSTEM_INSTRUCTION + (currentStory ? PARAGRAPH_CONTEXT_INSTRUCTION_SUFFIX : '');

    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_TEXT,
      contents: fullPrompt,
      config: {
        systemInstruction: systemInstruction,
      }
    });
    
    return response.text.trim();
  } catch (error) {
    console.error('Error generating story paragraph:', error);
     if (error instanceof Error) {
        throw new Error(`Failed to generate paragraph from Gemini API: ${error.message}`);
    }
    throw new Error('An unknown error occurred while generating the paragraph.');
  }
};

export const suggestStoryEdits = async (storyContent: string): Promise<string> => {
  if (!apiKey) throw new Error("API Key is not configured.");
  if (!storyContent || storyContent.trim() === '') {
    throw new Error('Story content cannot be empty for editing.');
  }
  try {
    const prompt = `Original Story:\n${storyContent}`;
    
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_TEXT,
      contents: prompt,
      config: {
        systemInstruction: EDIT_SUGGESTION_SYSTEM_INSTRUCTION,
      }
    });
    
    // The instruction asks for ONLY the edited text.
    return response.text.trim(); 
  } catch (error) {
    console.error('Error suggesting story edits:', error);
     if (error instanceof Error) {
        throw new Error(`Failed to suggest edits from Gemini API: ${error.message}`);
    }
    throw new Error('An unknown error occurred while suggesting edits.');
  }
};